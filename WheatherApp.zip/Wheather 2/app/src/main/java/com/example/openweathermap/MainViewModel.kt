package com.example

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.adapters.WeatherModel

class MainViewModel:ViewModel () {
    var liveDataCurrent = MutableLiveData <WeatherModel>()
    var liveDataList = MutableLiveData <List<WeatherModel>>()
}